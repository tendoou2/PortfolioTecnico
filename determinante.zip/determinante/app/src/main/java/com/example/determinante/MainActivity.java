package com.example.determinante;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText m1, m2, m3, m4, m5, m6, m7, m8, m9;
    TextView mat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        m1 = findViewById(R.id.nn);
        m2 = findViewById(R.id.nn18);
        m3 = findViewById(R.id.nn19);
        m4 = findViewById(R.id.nn20);
        m5 = findViewById(R.id.nn21);
        m6 = findViewById(R.id.nn22);
        m7 = findViewById(R.id.nn23);
        m8 = findViewById(R.id.nn24);
        m9 = findViewById(R.id.nn25);
        mat = findViewById(R.id.resultado);
    }
    public void determinaU(View v){
        int det = "determinante\n";

        int a = m1*m5*m9;
        int b = m2*m6*m7;
        int c = m3*m4*m8;
        int d = m2*m4*m9;
        int e = m1*m6*m8;
        int f = m3*m5*m7;
        int resultado = a-b-c+d+e-f;

        det += resultado;

        mat.setText(det);


    }
}
