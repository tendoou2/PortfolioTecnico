package com.example.prisma;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton rat, rab, rav, rn,rf, rv, rh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        rat = findViewById(R.id.rbAt);
        rab = findViewById(R.id.rbAbv);
        rav = findViewById(R.id.rbAbt);
        rn = findViewById(R.id.rbN);
        rf = findViewById(R.id.rbF);
        rv = findViewById(R.id.rbV);
        rh = findViewById(R.id.rbA);
    }
    public void proseguir(View abacate){
        Intent i = new Intent (this,Conta.class);
    if(rat.isChecked()){//formula da area base pela area total At = 2*Ab + N * f
        Conta.conta = 1;
        startActivity(i);
        //formula da area total At = 2
    }
    else if(rab.isChecked()){//formula da area da base pelo volume Ab = At - n*F /2
        Conta.conta = 2;
        startActivity(i);
    }
    else if(rav.isChecked()){ //Ab=v/h
        Conta.conta = 3;
        startActivity(i);
    }
    else if(rn.isChecked()){//forula de numeros de bases F = (At - 2*Ab) / F
        Conta.conta = 4;
        startActivity(i);
    }
    else if(rf.isChecked()){//formula de areas de faces F = (At - 2*Ab) / N
        Conta.conta = 5;
        startActivity(i);
    }
    else if(rv.isChecked()){ //formula de volume V = Ab*H
        Conta.conta = 6;
        startActivity(i);
    }
    else if(rh.isChecked()){//formula da altura H = V/ab
        Conta.conta = 7;
        startActivity(i);
    }
    else {//nenhum foi selecionado
        Toast.makeText(this,"nenhuma opçao foi selecionada",Toast.LENGTH_LONG).show();

    }
    }
}