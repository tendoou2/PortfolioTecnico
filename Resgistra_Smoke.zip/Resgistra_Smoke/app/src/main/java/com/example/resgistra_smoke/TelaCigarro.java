
package com.example.resgistra_smoke;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class TelaCigarro extends AppCompatActivity {
    ImageView FundoN, FundoP, FundoC, FundoM;
    Registro  textoN;
    boolean rog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_tela_cigarro);
        FundoN = findViewById(R.id.imgN);
        FundoC = findViewById(R.id.imgC);
        FundoP = findViewById(R.id.imgP);
        FundoM = findViewById(R.id.imgM);
      //  textoN = findViewById(R.id.cigaTV);
    }

    public void botaoImgC(View v) {
        Registro.texto = "Cigarro";
        Intent i = new Intent(this, Registro.class);
        startActivity(i);
    }

    public void botaoImgN(View v) {
        Registro.texto = "Nargas";
        Intent i = new Intent(this, Registro.class);
        startActivity(i);

    }

    public void botaoImgP(View v) {
        Registro.texto = "Pendrive";
        Intent i = new Intent(this, Registro.class);
        startActivity(i);
    }

    public void botaoImgM(View v) {
        Registro.texto = "Maconha";
        Intent i = new Intent(this, Registro.class);
        startActivity(i);
        }
    }
