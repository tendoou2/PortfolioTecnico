package com.example.resgistra_smoke;

public class Fumos {
    String tipo;

    public Fumos(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
