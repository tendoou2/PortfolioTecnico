package com.example.resgistra_smoke;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegistroBD {
    String tipo;
    String usuario;
    int qtdTragadas;

    public RegistroBD(String tipo, String usuario, int qtdTragadas) {
        this.tipo = tipo;
        this.usuario = usuario;
        this.qtdTragadas = qtdTragadas;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getQtdTragadas() {
        return qtdTragadas;
    }

    public void setQtdTragadas(int qtdTragadas) {
        this.qtdTragadas = qtdTragadas;
    }


    public void salvarRegistro(){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        ref.child("Usuario").child(usuario).setValue(this);
    }
}
