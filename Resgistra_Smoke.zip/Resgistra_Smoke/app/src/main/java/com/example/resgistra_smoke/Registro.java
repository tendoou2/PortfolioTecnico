package com.example.resgistra_smoke;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Registro extends AppCompatActivity {

    int tragadasC = 0;
    int tragadasN = 0;
    int tragadasP = 0;
    EditText qdt;
    static String texto;
    TextView txt;
    static UsuarioBd logado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        getSupportActionBar().hide();
        qdt = findViewById(R.id.qtd);
        txt = findViewById(R.id.cigaTV);
        Toast.makeText(this,texto,Toast.LENGTH_LONG).show();
        txt.setText(texto);
    }

    public void registrarCigarro(View v){
        RegistroBD r = new RegistroBD("cigarro", "boemer", 15);
        logado.registro = r;
        r.salvarRegistro();

        tragadasC = Integer.parseInt(qdt.getText().toString());
        tragadasN = Integer.parseInt(qdt.getText().toString());
        qdt.setText(null);



        if (tragadasC > 4){
            Toast.makeText(this, "Tu ja fumou um monte doidao", Toast.LENGTH_LONG).show();
        }
        else if (tragadasC <= 7){
            Toast.makeText(this, "Você ainda esta dentro do limite toleravel!", Toast.LENGTH_SHORT).show();
        }

        if (tragadasN > 8){
            Toast.makeText(this, "Tu ja está fumando a bastante, hora de parar!", Toast.LENGTH_LONG).show();
        }
        else if (tragadasC <= 7){
            Toast.makeText(this, "Você ainda esta dentro do limite toleravel!", Toast.LENGTH_SHORT).show();
        }

        else{
            Toast.makeText(this, "Você ainda esta dentro do limite toleravel!", Toast.LENGTH_SHORT).show();
        }
    }
}